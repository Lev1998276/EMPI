import os
import fnmatch
import configparser
import re



def read_config(file_path='config_person.ini'):
    try:
        config = configparser.ConfigParser()
        config.read(file_path)
        return config
    except Exception as e:
        print(f"An error occurred while reading the configuration file: {e}")
        

def extract_error_file_names(file_path):
    try:
        with open(file_path, 'r') as file:
            log_lines = file.read()

            # Define a regular expression pattern to match the file names
            file_name_pattern = r'File\s(.*\.json)'

            # Use re.findall to extract file names from the log lines
            file_names = re.findall(file_name_pattern, log_lines)

            return file_names
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []




def read_posted_records_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            records = [line.strip() for line in file.readlines()]
            return records
    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return []
    except Exception as e:
        print(f"An error occurred: {e}")
        return []

     
if __name__ == "__main__":
    config = read_config()
    error_directory_path = config.get('Person', 'error_file')      
    error_file_name = 'error_records.txt'
    error_file_path = os.path.join(error_directory_path, error_file_name)
    print(f"error_file_path : {error_file_path}\n")

    error_file_names_list = extract_error_file_names(error_file_path)
    for eachFile  in error_file_names_list:
        print(f"File {eachFile} was not posted")

    config = read_config()
    posted_directory_path = config.get('Person', 'posted_json')      
    posted_file_name = 'posted_records.txt'
    posted_file_path = os.path.join(posted_directory_path, posted_file_name)
    print(f"\nposted_file_path : {posted_file_path}\n")

    posted_file_names_list = read_posted_records_from_file(posted_file_path)
    for eachFile  in posted_file_names_list:
        print(f"File {eachFile} was posted")
